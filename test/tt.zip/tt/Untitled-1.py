
input = [[0,0,1,1,0,1],
         [1,0,0,1,0,1],
         [1,0,0,1,0,1],
         [1,1,1,0,0,1],
         [1,0,0,1,1,1],
         [1,0,0,1,0,0]]

def find(nx, ny, map, visit, count):
    if visit[ny][nx] == 1:
        return 0
    if map[ny][nx] == 0:
        return 0
    visit[ny][nx] = 1
    if ny-1>=0:
        if map[ny-1][nx]==1 and visit[ny-1][nx]==0:
            count += find(nx,ny-1,map,visit,count)
    if ny+1<=len(map)-1:
        if map[ny+1][nx]==1 and visit[ny+1][nx]==0:
            count += find(nx,ny+1,map,visit,count)
    if nx-1>=0:
        if map[ny][nx-1]==1 and visit[ny][nx-1]==0:
            count += find(nx-1,ny,map,visit,count)
    if nx+1<=len(map)-1:
        if map[ny][nx+1]==1 and visit[ny][nx+1]==0:
            count += find(nx+1,ny,map,visit,count)
    return count + 1


def solution(map):
    answer = []
    visit = [[0 for _ in range(len(map))] for _ in range(len(map)) ]
    for y in range(len(map)):
        for x in range(len(map)):
            if map[y][x]==1 and visit[y][x]==0:
                count = 0
                count = find(x,y,map,visit,count)
                answer.append(count)
    answer.sort()
    answer.reverse()
    return answer

print(solution(input))